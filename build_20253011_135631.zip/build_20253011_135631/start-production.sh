#/bin/bash
export NODE_ENV=production
cd backend
node server.js
